const WEATHER_API_KEY = "3a81a6f94cfc47cdc20b83dc44ee0694";
const NEWS_API_KEY = "3c8ece544cb940f0be397ccf1ce49ca7";

function showMainPage() {
  document.getElementById("landingPage").style.display = "none";
  document.getElementById("mainPage").style.display = "block";
}

async function getWeather() {
  const city = document.getElementById("cityInput")?.value || "Delhi";
  const weatherBox = document.getElementById("weatherResult");
  const forecastBox = document.getElementById("forecastResult");
  const newsBox = document.getElementById("newsResult");

  // Clear previous content
  weatherBox.innerHTML = "";
  forecastBox.innerHTML = "";
  newsBox.innerHTML = "<h3>🌐 Latest Weather & Climate News</h3>";

  const weatherURL = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${WEATHER_API_KEY}&units=metric`;
  const forecastURL = `https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${WEATHER_API_KEY}&units=metric`;
  const newsURL = `https://newsapi.org/v2/everything?q=weather+India&sortBy=publishedAt&apiKey=${NEWS_API_KEY}&pageSize=10`;

  try {
    const [weatherRes, forecastRes, newsRes] = await Promise.all([
      fetch(weatherURL),
      fetch(forecastURL),
      fetch(newsURL)
    ]);

    const weatherData = await weatherRes.json();
    const forecastData = await forecastRes.json();
    const newsData = await newsRes.json();

    // Fetch AQI data
    const { lat, lon } = weatherData.coord;
    const airPollutionURL = `https://api.openweathermap.org/data/2.5/air_pollution?lat=${lat}&lon=${lon}&appid=${WEATHER_API_KEY}`;
    const airRes = await fetch(airPollutionURL);
    const airData = await airRes.json();

    const aqi = airData.list[0].main.aqi; // 1-5
    const pm25 = airData.list[0].components.pm2_5;
    const pm10 = airData.list[0].components.pm10;
    const aqiTextMap = {
      1: "Good",
      2: "Fair",
      3: "Moderate",
      4: "Poor",
      5: "Very Poor"
    };
    const aqiText = aqiTextMap[aqi] || "Unknown";

    // Greeting and advice logic
    const hour = new Date().getHours();
    let greeting = "Good Night 🌙";
    if (hour >= 5 && hour < 12) greeting = "Good Morning ☀️";
    else if (hour >= 12 && hour < 17) greeting = "Good Afternoon 🌞";
    else if (hour >= 17 && hour < 20) greeting = "Good Evening 🌇";

    const weatherMain = weatherData.weather[0].main.toLowerCase();
    let advice = "";
    if (weatherMain.includes("rain")) advice = "Rainy – Carry an umbrella!";
    else if (weatherMain.includes("cloud")) advice = "Cloudy – May stay dry";
    else if (weatherMain.includes("clear")) advice = "Sunny day – No rain expected";
    else advice = "Mild weather – Enjoy your day!";

    // Weather animations control
    const rain = document.querySelector(".rain");
    const wind = document.querySelector(".wind");
    const sun = document.querySelector(".sunshine");
    const cloud = document.querySelector(".cloudy");
    [rain, wind, sun, cloud].forEach(el => el.style.display = "none");
    if (weatherMain.includes("rain")) rain.style.display = "block";
    if (weatherMain.includes("clear")) sun.style.display = "block";
    if (weatherMain.includes("cloud")) cloud.style.display = "block";
    if (weatherData.wind.speed > 4.5) wind.style.display = "block";

    // Weather display with AQI
    weatherBox.innerHTML = `
      <div class="weather-box">
        <div class="greeting">${greeting}</div>
        <h3>${weatherData.name}, ${weatherData.sys.country}</h3>
        <img class="weather-icon" src="https://openweathermap.org/img/wn/${weatherData.weather[0].icon}@2x.png" />
        <div class="temp">${weatherData.main.temp.toFixed(2)}°C</div>
        <p>📌 ${weatherData.weather[0].main} - ${weatherData.weather[0].description}</p>
        <p>🧪 Feels like: ${weatherData.main.feels_like.toFixed(2)}°C</p>
        <p>💧 Humidity: ${weatherData.main.humidity}%</p>
        <p>🌬️ Wind: ${weatherData.wind.speed} m/s</p>
        <p>☁️ Cloudiness: ${weatherData.clouds.all}%</p>
        <p>⚠️ ${advice}</p>
        <hr>
        <p>🌫️ <strong>Air Quality:</strong> ${aqiText} (AQI Level: ${aqi})</p>
        <p>PM2.5: ${pm25} µg/m³, PM10: ${pm10} µg/m³</p>
      </div>
    `;

    // Forecast display
    const now = new Date();
    const nextHours = forecastData.list
      .filter(item => new Date(item.dt_txt) > now)
      .slice(0, 6);

    const forecastHTML = nextHours.map(item => {
      const time = new Date(item.dt_txt).toLocaleTimeString("en-IN", {
        hour: '2-digit',
        minute: '2-digit'
      });
      return `
        <div class="forecast-card">
          <p><strong>${time}</strong></p>
          <img src="https://openweathermap.org/img/wn/${item.weather[0].icon}@2x.png" />
          <p>${item.main.temp.toFixed(1)}°C</p>
        </div>
      `;
    }).join("");

    forecastBox.innerHTML = `
      <h3>Next Few Hours</h3>
      <div class="forecast-container">${forecastHTML}</div>
    `;

    // News display
    if (newsData.articles.length === 0) {
      newsBox.innerHTML += "<p>No news found.</p>";
    } else {
      newsBox.innerHTML += `<div class="news-scroll-area">`;
      newsData.articles.forEach(article => {
        newsBox.innerHTML += `
          <div class="news-card">
            <h4>${article.title}</h4>
            <p>${article.description || "No description available."}</p>
            <a href="${article.url}" target="_blank">Read more →</a>
          </div>
        `;
      });
      newsBox.innerHTML += `</div>`;
    }

  } catch (err) {
    weatherBox.innerHTML = "<p>❌ Unable to fetch data. Check connection or city name.</p>";
  }
}
